﻿Function.prototype.member = function(name, value){
	this.prototype[name] = value
}

//////// Game Definition
function Game(){}
Game.start = function(room, welcome){
	game.start(room.id)
	printMessage(welcome)
}
Game.end = function(){
	game.clear()
}
Game.move = function(room){
	game.move(room.id)	
}
Game.handItem = function(){
	return game.getHandItem()
}


//////// Room Definition

function Room(name, background){
	this.name = name
	this.background = background
	this.id = game.createRoom(name, background)
}
Room.member('setRoomLight', function(intensity){
	this.id.setRoomLight(intensity)
})

//////// Object Definition

function Object(room, name, image){
	this.room = room
	this.name = name
	this.image = image

	if (room !== undefined){
		this.id = room.id.createObject(name, image)
	}
}
Object.STATUS = { OPENED: 0, CLOSED: 1, LOCKED: 2 }

Object.member('setSprite', function(image){
	this.image = image
	this.id.setSprite(image)
})
Object.member('resize', function(width){
	this.id.setWidth(width)
})
Object.member('setDescription', function(description){
	this.id.setItemDescription(description)
})

Object.member('getX', function(){
	return this.id.getX()
})
Object.member('getY', function(){
	return this.id.getY()
})
Object.member('locate', function(x, y){
	this.room.id.locateObject(this.id, x, y)
})
Object.member('move', function(x, y){
	this.id.moveX(x)
	this.id.moveY(y)
})

Object.member('show', function(){
	this.id.show()
})
Object.member('hide', function(){
	this.id.hide()
})
Object.member('open', function(){
	this.id.open()
})
Object.member('close', function(){
	this.id.close()
})
Object.member('lock', function(){
	this.id.lock()
})
Object.member('unlock', function(){
	this.id.unlock()
})
Object.member('isOpened', function(){
	return this.id.isOpened()
})
Object.member('isClosed', function(){
	return this.id.isClosed()
})
Object.member('isLocked', function(){
	return this.id.isLocked()
})
Object.member('pick', function(){
	this.id.pick()
})
Object.member('isPicked', function(){
	return this.id.isPicked()
})

//////// Door Definition

function Door(room, name, closedImage, openedImage, connectedTo, width, x, y){
	Object.call(this, room, name, closedImage)

	// Door properties
	this.closedImage = closedImage
	this.openedImage = openedImage
	this.connectedTo = connectedTo

	this.resize(width)
	this.locate(x, y)
}
// inherited from Object
Door.prototype = new Object()

Door.member('onClick', function(){
	if (!this.id.isLocked() && this.id.isClosed()){
		this.id.open()
	}
	else if (this.id.isOpened()){
		if (this.connectedTo !== undefined){
			Game.move(this.connectedTo)
		}
		else {
			Game.end()
		}
	}
})
Door.member('onOpen', function(){
	this.id.setSprite(this.openedImage)
})
Door.member('onClose', function(){
	this.id.setSprite(this.closedImage)
})


//////// Keypad Definition

function Keypad(room, name, image, password, callback){
	Object.call(this, room, name, image)

	// Keypad properties
	this.password = password
	this.callback = callback
}
// inherited from Object
Keypad.prototype = new Object()

Keypad.member('onClick', function(){
	showKeypad('number', this.password, this.callback)
})


//////// DoorLock Definition
function DoorLock(room, name, image, password, door, message){
	Keypad.call(this, room, name, image, password, function(){
		printMessage(message)
		door.unlock()
	})
}
// inherited from Object
DoorLock.prototype = new Keypad()

/////// Item Definition

function Item(room, name, image, width, x, y){
	Object.call(this, room, name, image)
	this.resize(width)
	this.locate(x, y)
}
// inherited from Object
Item.prototype = new Object()

Item.member('onClick', function(){
//	this.id.pick()
})


Item.member('isHanded', function(){
	return Game.handItem() == this.id
})



//이까지 재정의




room1 = new Room('room1', '거실.png')		// 변수명과 이름이 일치해야 한다.
room2 = new Room('room2', '애기방.png')		// 변수명과 이름이 일치해야 한다.
room3 = new Room('room3', '아빠방.png')		// 변수명과 이름이 일치해야 한다.
room4=new Room('room4', '주방.png')

room1.door1 = new Door(room1, 'door1', '거실문닫힘.png', '거실문열림.png', room2, 70, 1010, 240)
r1opencounter=0

room1.door1.onClick=function()
{
	if(room1.door1.isOpened()){
		playSound("아기웃는소리.wav")
		Game.move(room2)
	}
	else if(room1.door1.isLocked())
	{
		if(r1opencounter==5)
		{
			room1.door1.open()	
		}
		else
		{
			printMessage("잠겨있음")		
		}
	}	
		

}

room1.door1.lock()



//방1 배경소품
room1.carpet=new Item(room1, 'carpet', '1카페트.png', 700, 600, 500)
room1.aircon=new Item(room1, 'aircon', '1에어컨.png', 200, 150, 100)
//room1.tv=new Item(room1, 'tv', '1TV.png', 100, 200, 240)
room1.table=new Item(room1, 'table', '1큰상.png', 400, 700, 500)
godtrigger=0
mealtrigger=0
room1.table.onClick=function()
{
	//printMessage('a')
	if(room4.realmeal.isHanded())
	{
		if(mealtrigger==0)
		{
			room1.meal.show()
			room1.god.show()
			printMessage("필,,필승! 아,,아니 여보! 언제 왔어????")
			playSound("브롤스타즈 BGM - 승리.wav")
			mealtrigger++
		}
	}	
}
room1.breakfast=new Item(room1,'breakfast', '1아침식사.png', 250, 700, 450)
breakfastcounter=0
room1.breakfast.onClick=function()
{
	if(breakfastcounter==0)
	{
		printMessage("후우 뭘 좀 먹었더니 살 것 같다. 엇 옆에 쪽지가 있네?")
		memcounter=1
		room1.breakfast.setSprite('1아침식사끝.png')
	}
	else if(breakfastcounter==1)
	{
		printMessage("아침밥상을 다 치웠다")
		room1.breakfast.hide()
		r1opencounter++
	}
	breakfastcounter++
}


room1.meal=new Item(room1, 'meal', '4라면완성.png', 100, 700, 450)
room1.meal.hide()



memcounter=0
room1.mem=new Item(room1, 'mem', '1포스트잇.png', 50, 850, 480)
room1.mem.onClick=function()
{
	
	if(memcounter==1)
	{
		memcounter++
		playSound("브롤스타즈 BGM - 메인화면.wav")
		room1.memo.show()	
	}
	else if(memcounter==2)
	{
		room1.memo.show()	
	}
	
	
			
}
ttt=0
//고정 객체
room1.tokitchenshadow=new Item(room1, 'tokitchenshadow', '투명세로.png', 200, 1250, 550)
room1.tokitchenshadow.onClick=function()
{
	
	if(tokitchen==1)
	{
		if(ttt==0)
		{
			printMessage("라면이나 끓여먹어야지")
			ttt=1
		}
		
		Game.move(room4)
	}
	else
	{
		printMessage("지금은 주방에 볼 일이 없다")
	}
}
room1.carpetshawdow=new Item(room1, 'carpetshawdow', '투명가로.png', 200, 600, 600)
room1.carpetshawdow.close()
room1.carpetshawdow.onClick=function(){
	
	if(this.id.isClosed())
	{
		if(!Game.handItem())
		{
			//printMessage(this.name)	
		}
		else
		{
			if(room1.envelope.isHanded())
			{
				this.id.open()
				printMessage("비상금은 항상 아무도 모르게 챙겨두자…")
				r1opencounter++		
			}
			else if(room1.milkpowder.isHanded())
			{
				
				game.setGameoverMessage("그걸 카펫 밑에 넣어서 어쩌자는거야")

				game.gameover()
		
				//printMessage(room1.milkpowder.name+"잘못 넣음 게임 종료")
		
			}
			else if(room1.goldfish.isHanded())
			{
				game.setGameoverMessage("졌다! 오늘 저녁은 피쉬앤그릴이다!")
				game.gameover()
		
				printMessage(room1.goldfish.name+"잘못 넣음 게임 종료")
		
			}
			else if(room1.soju.isHanded())
			{

				game.setGameoverMessage("애기 : 아빠 이따 밤에 엄마 몰래 한잔 기기?")
				game.gameover()

				printMessage(room1.soju.name+"잘못 넣음 게임 종료")
			}
		}
	}
	else
	{
		printMessage("완료")
	}
}

room1.cradle=new Item(room1, 'cradle', '1TV.png', 150, 150, 270)
room1.cradle.close()
room1.cradle.onClick=function(){
	
	if(this.id.isClosed())//close 상태일 때
	{
		if(!Game.handItem())//아무것도 안 가지고 있을 때
		{
			printMessage("TV가 밤새 켜져 있었네")	
		}
		else
		{
			if(room1.milkpowder.isHanded())
			{
				this.id.open()
				room1.cradle.setSprite("1TV-꺼짐.png")
				printMessage("TV를 껐다. 전기세 아껴야지;;")
				r1opencounter++
				
			}
			else if(room1.envelope.isHanded())
			{
				game.setGameoverMessage("동작 그만! 밑장 빼기냐!")
				game.gameover()
				//printMessage(room1.envelope.name+"잘못 넣음 게임 종료")
		
			}
			else if(room1.goldfish.isHanded())
			{
				game.setGameoverMessage("졌다! 오늘 저녁은 피쉬앤그릴이다!")
				game.gameover()
				//printMessage(room1.goldfish.name+"잘못 넣음 게임 종료")
				
		
			}
			else if(room1.soju.isHanded())
			{	
				game.setGameoverMessage("애기 : 아빠 이따 밤에 엄마 몰래 한잔 기기?")
				game.gameover()
				//printMessage(room1.soju.name+"잘못 넣음 게임 종료")
			}
		}
	}
	else//open 상태
	{
		printMessage("완료")
	}
}



room1.sofa=new Item(room1, 'sofa', '1쇼파.png', 170, 1050, 400)
room1.sofa.close()
room1.sofa.onClick=function(){

	if(this.id.isClosed())
	{
		if(!Game.handItem())
		{
			printMessage("어젯밤에 만취해서 들어오자마자 소파에서 잔 것 같다")	
		}
		else
		{
			if(room1.soju.isHanded())
			{
				this.id.open()
				printMessage("이따 마눌님 주무시면 혼술 조져야지 히히")
				r1opencounter++		
			}
			else if(room1.milkpowder.isHanded())
			{
				game.setGameoverMessage("리모컨을 소파에 넣다가 망가뜨렸다")
				game.gameover()

				//printMessage(room1.milkpowder.name+"잘못 넣음 게임 종료")
		
			}
			else if(room1.goldfish.isHanded())
			{
				game.setGameoverMessage("졌다! 오늘 저녁은 피쉬앤그릴이다!")
				game.gameover()

				//printMessage(room1.goldfish.name+"잘못 넣음 게임 종료")
		
			}
			else if(room1.envelope.isHanded())
			{
				game.setGameoverMessage("동작 그만! 밑장 빼기냐!")

				game.gameover()

				//printMessage(room1.envelope.name+"잘못 넣음 게임 종료")
			}
		}
	}
	else
	{
		printMessage("완료")
	}
}

room1.fishbowl=new Item(room1, 'fishbowl', '1어항.png', 200, 450, 300)
room1.fishbowl.close()
room1.fishbowl.onClick=function(){
	if(this.id.isClosed())
	{
		if(!Game.handItem())
		{
			printMessage("어항이 왜 비어있지?")	
		}
		else
		{
			if(room1.goldfish.isHanded())
			{
				this.id.open()
				printMessage("넌 내게 어장관리를 했어…!")
				r1opencounter++	
			}
			else if(room1.milkpowder.isHanded())
			{
				
				game.setGameoverMessage("리모컨을 어항에 넣어서 고장내버림")


				game.gameover()

				//printMessage(room1.milkpowder.name+"잘못 넣음 게임 종료")
		
			}
			else if(room1.soju.isHanded())
			{
				game.setGameoverMessage("애기 : 아빠 이따 밤에 엄마 몰래 한잔?")
				game.gameover()

				//printMessage(room1.soju.name+"잘못 넣음 게임 종료")
		
			}
			else if(room1.envelope.isHanded())
			{
				game.setGameoverMessage("동작 그만! 밑장 빼기냐!")
				game.gameover()

				//printMessage(room1.envelope.name+"잘못 넣음 게임 종료")
			}

		}
	}
	else
	{
		printMessage("완료")
	}
}

//방1 사용 아이템

goldfishcounter=0
room1.goldfish=new Item(room1, 'goldfish', '1금붕어.png', 50, 1000, 600)
room1.goldfish.onClick=function(){
	if(goldfishcounter==0)
	{
		printMessage("양지바른 곳에, 아, 아니 어항에 넣어줘야지ㅋㅋ")
		goldfishcounter++
	}
	else
	{
		room1.goldfish.pick()
		printMessage("금붕어 획득")
	}

}

milkpowdercounter=0
room1.milkpowder=new Item(room1, 'milkpowder', '1리모컨.png', 50, 700, 300)
room1.milkpowder.onClick=function(){
	if(milkpowdercounter==0)
	{
		printMessage("리모컨이다. 잃어버리기 아주 쉬운 물건이지")
		milkpowdercounter++
	}
	else
	{
		room1.milkpowder.pick()
		printMessage("리모컨 획득")
	}

}

sojucounter=0
room1.soju=new Item(room1, 'soju', '1소주병.png', 30, 400, 500)
room1.soju.onClick=function(){
	if(sojucounter==0)
	{
		printMessage("술이 한잔 생각나는 대낮이군")
		sojucounter++
	}
	else
	{
		room1.soju.pick()
		printMessage("소주 획득")
	}

}

envelopecounter=0
room1.envelope=new Item(room1, 'envelope', '1돈.png', 40, 150, 450)
room1.envelope.onClick=function(){
	if(envelopecounter==0)
	{
		printMessage("어째서 비상금이 여기에?? 안 들키게 숨겨야 해")
		envelopecounter++
	}
	else
	{
		room1.envelope.pick()
		printMessage("돈봉투 획득")
	}

}
room1.god=new Item(room1, 'god', '아내.png', 150, 377, 500)
room1.god.onClick=function()
{
	if(godtrigger==0)
	{
		printMessage("아내 : 난 항상 네놈을 지켜보고 있단다. ")
	}
	else if(godtrigger==1)
	{
		printMessage("..!")
	}
	else if(godtrigger==2)
	{
		printMessage("아내 : 농담이야 농담~~~ㅎㅎㅎ 방금 왔어ㅎㅎㅎ 나 몰래 게임은 많이 했어?")
	}
	else if(godtrigger==3)
	{
		printMessage("아니 저 그게...")
	}
	else if(godtrigger==4)
	{
		printMessage("아내 : 어? 라면 먹으려구? 마침 배고팠는데 나 한 젓가락만 먹자 ㅎㅎ")
	}
	else if(godtrigger==5)
	{
		printMessage("하… 황금 같은 주말도 이렇게 지나가는군…ㅜ.ㅜ ")
	}
	else if(godtrigger==6)
	{
		game.setClearMessage("대한민국 30대 남편분들… 힘내시기 바랍니다*^^* The End..")
		playSound("엔딩.wav")
		game.clear()
	}
	godtrigger++
}
room1.god.hide()
room1.memo=new Item(room1, 'memo', '쪽지내용.png', 700, 600, 400)
room1.memo.hide()
room1.memo.onClick=function()
{
	room1.memo.hide()
	printMessage("연애할 때에는 분명 이러지 않았었는데…밥차려준게 어디냐. 하 일단 청소부터 해볼까..")	
}


//방 2 시작
room2.door1 = new Door(room2, 'door1', '문-왼쪽-닫힘.png', '문-왼쪽-열림.png', room1, 120, 200, 296)
room2.door1.open()

room2.door2 = new Door(room2, 'door2', '문-오른쪽-닫힘.png', '문-오른쪽-열림.png', room3, 120, 1000, 278)
room2.door2.lock()

//배경
room2.bed=new Item(room2, 'bed', '2아기침대-측면.png',200, 800, 380) 
room2.mobile=new Item(room2, 'mobile', '2아기모빌.png',200, 800, 250)
room2.babytable=new Item(room2, 'babytable', '2아기책상.png', 180, 300, 600)
//사용아이템
room2.doll=new Item(room2, 'doll', '2아기인형.png', 100, 300, 520)
room2.doll.onClick=function()
{
	printMessage("아기가 좋아하는 인형이다")
	room2.doll.pick()	
}

room2.milk=new Item(room2, 'milk', '2우유.png', 100, 200, 500)
room2.milk.onClick=function()
{
	printMessage("아기 분유다")
	room2.milk.pick()	
} 
room2.diaper=new Item(room2, 'diaper', '2기저귀.png', 100, 1100, 400) 
room2.diaper.onClick=function()
{
	printMessage("기저귀가 아무렇게나 굴러다니고 있네")
	room2.diaper.pick()	
} 
room2.toy=new Item(room2, 'toy', '2딸랑이.png', 100, 700, 550) 
room2.toy.onClick=function()
{
	printMessage("아기가 좋아하는 장난감이다. 아기가 울면 이걸로 달래야지")
	room2.toy.pick()	
}

//아기
babycounter=0
bxp=500
byp=500
bsize=100
babyhit=0
babystate=0
ondoll=0
onmilk=0
ondiaper=0
ontoy=0
tim=15
function phase(){
	bxp=Math.floor(Math.random()*1000+100)
	byp=Math.floor(Math.random()*200+400)
	room2.baby.locate(bxp, byp)
	babystate=Math.floor(Math.random()*3)
	
	game.setTime(tim)
	if(babystate==0)//밥 페이즈
	{
		onmilk=1
		ondiaper=0
		ondoll=0
		ontoy=0				
		babyrender()				
	}
	else if(babystate==1)//기저귀 페이즈
	{
		ondiaper=1
		onmilk=0
		ondoll=0
		ontoy=0
		babyrender()				
	}
	else if(babystate==2)//인형 페이즈
	{
		ondoll=1		
		onmilk=0
		ondiaper=0
		ontoy=0				
		babyrender()
	}
}
function toyphase(){
	ontoy=1
	ondiaper=0
	onmilk=0
	playSound("아기우는소리.wav")
	room2.baby.setSprite('2아기2.png')	
	game.setTime(tim)
	babycounter++		
	bxp=Math.floor(Math.random()*1000+100)
	byp=Math.floor(Math.random()*200+400)		
	bsize+=70
	room2.baby.resize(bsize)
	room2.baby.locate(bxp, byp)
}
function sleepbaby()
{
	if(babyhit==8)
	{
		room2.baby.close()
		room2.baby.resize(120)
		room2.baby.locate(800, 360)		
		room2.baby.setSprite("2아기잠듦.png")
		room2.door2.close()
		game.hideTimer()
	}	
}
function babyrender()
{
	if(babyhit<4)
	{
		playSound("아기웃는소리.wav")
		if(babystate==0)//밥 페이즈
		{
			room2.baby.setSprite('2아기1_밥.png')
		}
		else if(babystate==1)//기저귀 페이즈
		{
			room2.baby.setSprite('2아기1_기저귀.png')
		}
		else if(babystate==2)//인형 페이즈
		{
			room2.baby.setSprite('2아기1_인형.png')
		}
	}
	else//졸림
	{
		playSound("아기졸린소리.wav")
		if(babystate==0)//밥 페이즈
		{
			room2.baby.setSprite('2아기1_밥_졸림.png')
		}
		else if(babystate==1)//기저귀 페이즈
		{
			room2.baby.setSprite('2아기1_기저귀_졸림.png')
		}
		else if(babystate==2)//인형 페이즈
		{
			room2.baby.setSprite('2아기1_인형_졸림.png')
		}
	}
}	

function babyend()
{
	if(babycounter>3)//게임오버
	{
			
		playSound("아기화난소리.wav")
		room2.baby.setSprite('2아기2.png')
		room2.baby.resize(1200)
		room2.baby.locate(600, 300)
		game.setGameoverMessage("YOU DIED")
		game.setTime(1)
		room2.baby.onClick=function(){}		
	}
		
}

room2.baby=new Item(room2, 'baby', '2아기1.png', bsize, bxp, byp) 
room2.baby.open()
room2.baby.onClick=function()
{
if(room2.baby.isOpened())
{	
	if(babycounter==0)//최초 클릭
	{
		game.setTimer(tim, 1,"")
		toyphase()
	}//if(babycounter==0)//최초 클릭
	else//두번째부터
	{
		if(game.getLeftTime()>4)//시간초 성공
		{
			if(onmilk==1)
			{
				if(room2.milk.isHanded())
				{
					phase()
					babyhit++
					sleepbaby()
				}
				else
				{
					toyphase()
					babyend()
				}
				
			}
			else if(ondiaper==1)
			{
				if(room2.diaper.isHanded())
				{
					phase()
					babyhit++
					sleepbaby()
				}
				else
				{
					toyphase()
					babyend()
				}
			}
			else if(ondoll==1)
			{
				if(room2.doll.isHanded())
				{
					phase()
					babyhit++
					sleepbaby()
					babyend()
				}
				else
				{
					toyphase()
				}
			}
			else if(ontoy==1)
			{
				if(room2.toy.isHanded())
				{
					phase()
					
				}
				else
				{
					toyphase()
					babyend()
				
				}
			}
			
		}		
		else//조건 실패 딸랑이 페이즈로 변환
		{
			toyphase()
		}
	}//else//두번째부터
	//printMessage("babystate"+babystate+" "+"onmilk "+onmilk+"onidaper "+ondiaper+"ontoy "+ontoy+"babycounter "+babycounter)
}
else
{
	printMessage("아기가 잔다")
}
}

room2.door2.onClick=function()
{
	if(room2.door2.isClosed())
	{
		room2.door2.open()
	}
	else if(room2.door2.isOpened())
	{
		Game.move(room3)
		printMessage("겨우 아기를 재웠다. 스팀에 AOE2 결정판이 나왔다는데 빨리 사서 해봐야지")
	}
	else if(room2.door2.isLocked())
	{
		printMessage("잠겨있다")
	}
}

//방 3 시작

r1=0
r2=0
r3=0
tokitchen=0
room3.door1 = new Door(room3, 'door1', '문-왼쪽-닫힘.png', '문-왼쪽-열림.png', room2, 140, 200, 370)
room3.door1.open()
keypadcounter=0

room3.keypad = new Keypad(room3, 'keypad', '금고-왼쪽-닫힘.png', '4480', function(){
	keypadcounter=4
	room3.keypad.setSprite('금고-왼쪽-열림.png')
	printMessage("금고가 열렸다")	
	room3.card.show()
	
})

Keypad.member('onClick', function(){

	keypadcounter++
	
	if(keypadcounter==1)
	{
		printMessage("금고 안에 스팀결제 카드를 놔뒀었지")
		
	}
	else if(keypadcounter==2)
	{	
		printMessage("비밀번호가 기억이 안 난다. 그냥 평소에 하던 브롤스타즈나 해야겠다.") 
		showKeypad('number', this.password, this.callback)
		
	}
	else if(keypadcounter==3)
	{
		showKeypad('number', this.password, this.callback)
		keypadcounter--
		if(brolcounter==1 || brolcounter ==2)
		{
			printMessage("비밀번호가 기억이 안 난다. 그냥 브롤스타즈나 한 판 더 해야겠다")
		}
		else if(brolcounter>=3)
		{
			printMessage("브롤스타즈를 하다보니 기억났다. 마지막 판 체력이 비밀번호랑 똑같았어!")	
		}
	}
	
	
})

room3.keypad.resize(150)
room3.keypad.locate(575, 365)
room3.card=new Item(room3, 'card', '3카드.png', 30, 587, 380)
room3.card.hide()
room3.card.onClick=function()
{
	printMessage("게임을 했더니 배가 고프다. 카드는 놔두고 일단 주방에서 먹을 것좀 찾아볼까")
	tokitchen=1
}
room3.desk=new Item(room3, 'desk', '3책상.png', 350, 1000, 430)
room3.chair=new Item(room3, 'chair', '3의자.png', 200, 850, 480)
brolcounter=0
room3.computer=new Item(room3, 'computer', '3컴퓨터.png', 200, 990, 270)
room3.computer.onClick=function()
{
	room3.window.show()
	room3.brol.show()
	room3.folder.show()
	room3.end.show()
}
room3.window=new Item(room3, 'window', '3바탕화면.png', 1000, 600, 300)
room3.window.hide()
room3.end=new Item(room3, 'end', '3종료아이콘.png', 100, 200, 500)
room3.end.hide()
room3.end.onClick=function()
{
	room3.window.hide()
	room3.brol.hide()
	room3.folder.hide()
	room3.folderwindow.hide()
	room3.replay1.hide()
	room3.replay2.hide()
	room3.replay3.hide()
	room3.endfolder.hide()
	room3.end.hide()
}
room3.folder=new Item(room3, 'folder', '3폴더아이콘.png', 100, 200, 300)
room3.folder.hide()
room3.folder.onClick=function()
{
	room3.folderwindow.show()
	if(r1==1)
	{
		room3.replay1.show()
	}

	if(r2==1)
	{
		room3.replay2.show()
	}

	if(r3==1)
	{
		room3.replay3.show()
	}
	

	
	room3.endfolder.show()
}
room3.brol=new Item(room3, 'brol', '3브롤스타즈아이콘.png', 100, 200, 100)
room3.brol.onClick=function()
{
	
	brolcounter++

	if(brolcounter==1)
	{
		//printMessage("1번영상")
		playYoutube("https://www.youtube.com/watch?v=6V35bQTvfdo")
		r1=1
	}
	else if(brolcounter==2)
	{
		//printMessage("2번영상")
		playYoutube("https://www.youtube.com/watch?v=uCqwcvh957A")
		r2=1
	}
	else if(brolcounter==3)
	{
	
		playYoutube("https://www.youtube.com/watch?v=-h7qu882HDg&feature=youtu.be")
		r3=1
		
	}


}
room3.brol.hide()
room3.folderwindow=new Item(room3, 'folderwindow', '3폴더화면임시.png', 700, 700, 300)
room3.folderwindow.hide()
room3.replay1=new Item(room3, 'replay1', '3r1.png', 100, 500, 200)
room3.replay1.hide()
room3.replay1.onClick=function()
{
	//printMessage("1번영상")
	playYoutube("https://www.youtube.com/watch?v=6V35bQTvfdo")
}

room3.replay2=new Item(room3, 'replay2', '3r2.png', 100, 650, 200)
room3.replay2.hide()
room3.replay2.onClick=function()
{
	//printMessage("2번영상")
	playYoutube("https://www.youtube.com/watch?v=uCqwcvh957A")
}

room3.replay3=new Item(room3, 'replay3', '3r3.png', 100, 800, 200)
room3.replay3.hide()
room3.replay3.onClick=function()
{
	playYoutube("https://www.youtube.com/watch?v=-h7qu882HDg&feature=youtu.be")
	//playYoutube()
}
room3.endfolder=new Item(room3, 'endfolder', '3종료.png', 65, 1000, 100)
room3.endfolder.hide()
room3.endfolder.onClick=function()
{
	room3.folderwindow.hide()
	room3.replay1.hide()
	room3.replay2.hide()
	room3.replay3.hide()
	room3.endfolder.hide()
}

//방 4 시작
room4.shelf=new Item(room4, 'shelf', '4선반.png', 200, 600, 275)
room4.range=new Item(room4, 'range', '4전자레인지.png', 150, 600, 175)

room4.ref=new Item(room4, 'ref', '4냉장고.png', 220, 400, 250)
refcounter=0

room4.ref.onClick=function()
{	
	switch (refcounter)
	{
	case 0:
		room4.ref.setSprite('4냉장고-열림.png')
		room4.pa.show()
		room4.egg.show()
		refcounter=1
	break
	case 1:
		room4.pa.hide()
		room4.egg.hide()
		room4.ref.setSprite("4냉장고.png")
		refcounter=0
	break
	}
}
room4.hshelf=new Item(room4, 'hshelf', '4윗선반-닫힘.png', 350, 950, 70)
hshelfcounter=0
room4.hshelf.onClick=function()
{	
	
	switch (hshelfcounter)
	{
	case 0:
		room4.pot.show()
		room4.hshelf.setSprite('4윗선반-열림.png')
		hshelfcounter=1
	break
	case 1:
		room4.pot.hide()
		room4.hshelf.setSprite("4윗선반-닫힘.png")
		hshelfcounter=0
	break
	}
}
room4.ushelf=new Item(room4, 'ushelf', '4아랫선반-닫힘.png', 350, 920, 310)
ushelfcounter=0
room4.ushelf.onClick=function()
{	
	
	switch (ushelfcounter)
	{
	case 0:
		room4.ra.show()
		room4.cheese.show()
		room4.ushelf.setSprite('4아랫선반-열림.png')
		ushelfcounter=1
	break
	case 1:
		room4.ra.hide()
		room4.cheese.hide()
		room4.ushelf.setSprite("4아랫선반-닫힘.png")
		ushelfcounter=0
	break
	}
}
room4.pot=new Item(room4, 'pot', '4냄비.png', 100, 950, 80)
room4.pot.hide()
room4.pot.onClick=function()
{
	printMessage("라면은 양은냄비가 국룰이지")
	room4.pot.pick()
}
room4.cookie=new Item(room4, 'cookie', '4쿠키.png', 70, 500, 430)
room4.coffee=new Item(room4, 'coffee', '4컵.png', 25, 600, 400)
room4.ra=new Item(room4, 'ra', '4라면.png', 85, 970, 378)
room4.ra.hide()
room4.ra.onClick=function()
{
	printMessage("무난한 신라면")
	room4.ra.pick()
}
room4.pa=new Item(room4, 'pa', '4파.png', 70, 360, 300)
room4.pa.hide()
room4.pa.onClick=function()
{
	printMessage("파송송 계란탁!")
	room4.pa.pick()
}
room4.egg=new Item(room4, 'egg', '4달걀.png', 30, 420, 250)
room4.egg.hide()
room4.egg.onClick=function()
{
	printMessage("달걀이 딱 하나 남아있었네")
	room4.egg.pick()
}
room4.cheese=new Item(room4, 'cheese', '4치즈.png', 50, 970, 318)
room4.cheese.hide()
room4.cheese.onClick=function()
{
	printMessage("치즈도 넣어 먹어야지")
	room4.cheese.pick()
}
Item.member('onClick', function(){
//	this.id.pick()
})
room4.meal=new Item(room4, 'meal', '4냄비.png', 100, 827, 213)
room4.meal.onClick=function()
{
		
}
room4.meal.hide()

mealcounter=0
room4.shadowtor1=new Item(room4, 'shadowtor1', '투명세로.png', 100,40 , 500)
room4.shadowtor1.onClick=function()
{
	Game.move(room1)
}
room4.shadowfire=new Item(room4, 'shadowfire', '투명가로.png', 200, 830, 220)
raflag=0
paflag=0
eggflag=0
cheeseflag=0
room4.shadowfire.onClick=function()
{
	//printMessage("a")
	if(mealcounter==0)
	{
		if(room4.pot.isHanded())
		{
			
			room4.meal.show()
			mealcounter++
		}		
	}
	else if(mealcounter==5)
	{
		printMessage("라면 완성!")
		room4.meal.setSprite("4라면완성.png")
		mealcounter++
	}
	else if(mealcounter==6)
	{
		room4.meal.hide()
		room4.shadowfire.hide()
		room4.realmeal.show()
		room4.realmeal.pick()
		printMessage("거실 탁자에서 먹어야겠다")
	}
	else
	{
		if(room4.ra.isHanded())
		{
			if(raflag==0)
			{
				printMessage("라면을 넣었다")
				raflag=1
				mealcounter++
			}
		}	
		if(room4.pa.isHanded())
		{
			if(paflag==0)
			{
				printMessage("파를 넣었다")
				paflag=1
				mealcounter++
			}	
		}
		if(room4.egg.isHanded())
		{
			if(eggflag==0)
			{
				printMessage("달걀을 넣었다")
				eggflag=1
				mealcounter++
			}
		}
		if(room4.cheese.isHanded())
		{
			if(cheeseflag==0)
			{
				printMessage("치즈을 넣었다")
				cheeseflag=1
				mealcounter++
			}
		}

	}
}



room4.realmeal=new Item(room4, 'realmeal', '4라면완성.png', 100, 900, 50)
room4.realmeal.hide()



Game.start(room1, '평화로운 주말….어제 회식 때문에 너무 머리가 아프다… 엇 저기 아침밥상이 있군 아이조아')
